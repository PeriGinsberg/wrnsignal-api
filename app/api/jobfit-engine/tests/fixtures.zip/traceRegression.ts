// tests/traceRegression.ts
import cases from "./regressionCases.json"
import { JOBS, PROFILES } from "./fixtures"

import { evaluateJobFitV1 } from "../src/evaluateJobFitV1"
import { computeAlignment } from "../src/alignment"
import { computeExposure } from "../src/exposure"
import { runHardGates } from "../src/hardGates"
import { runExperienceMismatch } from "../src/experienceMismatch"
import { generateRisks } from "../src/tiering"

function main() {
  const failures: any[] = []

  for (const c of cases as any[]) {
    const profile = (PROFILES as any)[c.profile_id]
    const job = (JOBS as any)[c.job_id]
    if (!profile || !job) continue

    const hard = runHardGates(job, profile)
    const mismatch = runExperienceMismatch(job, profile)
    const a = computeAlignment(job, profile)
    const e = computeExposure(job, profile)
    const tiering = generateRisks(job, profile, a.alignment, e.exposure)

    const out = evaluateJobFitV1("v1.0", job, profile)

    const gotStructural = out.risks.filter((r) => r.risk_level === "STRUCTURAL").map((r) => r.code)
    const gotT2 = out.risks.filter((r) => r.risk_level === "ADDRESSABLE_GAP").length

    const mismatchReasons: string[] = []
    if (out.debug.alignment !== c.expected_alignment) mismatchReasons.push("ALIGNMENT")
    if (out.debug.exposure !== c.expected_exposure) mismatchReasons.push("EXPOSURE")
    if (out.decision !== c.expected_decision) mismatchReasons.push("DECISION")
    if (gotT2 !== c.expected_tier2_risk_count) mismatchReasons.push("TIER2_COUNT")
    if (hard.hard_fail !== c.expected_hard_gate_triggered) mismatchReasons.push("HARD_GATE")
    if ((c.expected_structural_risk_codes?.length ?? 0) !== gotStructural.length) mismatchReasons.push("STRUCTURAL_COUNT")

    if (mismatchReasons.length) {
      failures.push({
        case_id: c.case_id,
        profile_id: c.profile_id,
        job_id: c.job_id,
        mismatchReasons,
        expected: {
          decision: c.expected_decision,
          alignment: c.expected_alignment,
          exposure: c.expected_exposure,
          tier2_count: c.expected_tier2_risk_count,
          structural: c.expected_structural_risk_codes ?? [],
          hard_gate: c.expected_hard_gate_triggered,
        },
        got: {
          decision: out.decision,
          alignment: out.debug.alignment,
          exposure: out.debug.exposure,
          tier2_count: gotT2,
          structural: gotStructural,
          hard_gate: hard.hard_fail,
        },
        inputs: {
          job_role_families: job.role?.role_families ?? [],
          profile_target_families: profile.targets?.role_families ?? [],
          job_clusters: job.responsibility_clusters ?? [],
          profile_exec: profile.exposure_clusters?.executed ?? [],
          profile_adj: profile.exposure_clusters?.adjacent ?? [],
          profile_theory: profile.exposure_clusters?.theoretical ?? [],
        },
        hard,
        experienceMismatch: mismatch,
        alignmentDebug: a,
        exposureDebug: e,
        tieringDebug: {
          has_structural: tiering.has_structural,
          t2_count: tiering.t2_count,
          risks: tiering.risks.map((r: any) => ({ level: r.risk_level, code: r.code })),
        },
      })
    }
  }

  console.log(JSON.stringify({ failures: failures.length, items: failures }, null, 2))
}

main()